import type {
  AdminReportPage,
  AnalyticsDashboardResponse,
  DashboardMetrics,
  HeatmapResponse,
  ReportStatus,
  SeverityLevel,
  IncidentCategory,
  AdminReportDetail,
} from './types';

const API_BASE_URL =
  (import.meta as any).env.VITE_API_BASE_URL?.replace(/\/$/, '') || 'http://127.0.0.1:8000';

type RequestOptions = {
  signal?: AbortSignal;
};

function buildQuery(params: Record<string, string | number | undefined | null>) {
  const searchParams = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return;
    searchParams.set(key, String(value));
  });

  const query = searchParams.toString();
  return query ? `?${query}` : '';
}

async function requestJson<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
    },
    signal: options.signal,
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(detail || `Request failed with status ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export async function getAdminDashboardMetrics(options: RequestOptions = {}) {
  return requestJson<DashboardMetrics>('/api/v1/admin/dashboard/metrics', options);
}

export async function getAnalyticsDashboard(options: RequestOptions = {}) {
  return requestJson<AnalyticsDashboardResponse>('/api/v1/analytics/dashboard', options);
}

export async function getAdminReports(
  params: {
    page?: number;
    pageSize?: number;
    status?: ReportStatus;
    severity?: SeverityLevel;
    category?: IncidentCategory;
    zone?: string;
    search?: string;
  } = {},
  options: RequestOptions = {},
) {
  const query = buildQuery({
    page: params.page ?? 1,
    page_size: params.pageSize ?? 8,
    status: params.status,
    severity: params.severity,
    category: params.category,
    zone: params.zone,
    search: params.search,
  });

  return requestJson<AdminReportPage>(`/api/v1/admin/reports${query}`, options);
}

export async function getHeatmapPoints(options: RequestOptions = {}) {
  return requestJson<HeatmapResponse>('/api/v1/map/heatmap', options);
}

export async function exportReports(params: {
  format: 'csv' | 'pdf';
  status?: ReportStatus;
  severity?: SeverityLevel;
  category?: IncidentCategory;
  zone?: string;
  search?: string;
}): Promise<Blob> {
  const query = buildQuery({
    format: params.format,
    status: params.status,
    severity: params.severity,
    category: params.category,
    zone: params.zone,
    search: params.search,
  });

  const response = await fetch(`${API_BASE_URL}/api/v1/admin/export${query}`, {
    method: 'GET',
    headers: {
      Accept: params.format === 'pdf' ? 'application/pdf' : 'text/csv',
    },
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(detail || `Export failed with status ${response.status}`);
  }

  return response.blob();
}

export async function getAdminReportDetail(reportId: string, options: RequestOptions = {}) {
  return requestJson<AdminReportDetail>(`/api/v1/admin/reports/${reportId}`, options);
}