import { useEffect, useState } from 'react';
import SafeReportAdminDashboard from './dashboard';
import PublicReportForm from './pages/public_report_form';
import { ShieldAlert, Lock, LogIn } from 'lucide-react';

const ADMIN_DEMO_CODE = import.meta.env.VITE_ADMIN_DEMO_CODE || 'safereport-admin';
const AUTH_KEY = 'safereport_admin_demo_auth';

function AdminLogin({ onLogin }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (code.trim() === ADMIN_DEMO_CODE) {
      localStorage.setItem(AUTH_KEY, 'true');
      onLogin(true);
      return;
    }

    setError('Código inválido.');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4 text-slate-100">
      <div className="w-full max-w-md rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-500 text-slate-950">
            <ShieldAlert className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-semibold text-white">SafeReport Map</div>
            <div className="text-xs text-slate-400">Acesso restrito</div>
          </div>
        </div>

        <h1 className="text-2xl font-semibold text-white">Entrada restrita</h1>
        <p className="mt-2 text-sm leading-6 text-slate-400">
          Informe o código de acesso para abrir a área interna.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3">
            <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-wide text-slate-500">
              <Lock className="h-3.5 w-3.5" />
              Código de acesso
            </div>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-600"
              placeholder="Digite o código"
              type="password"
              autoComplete="off"
            />
          </div>

          {error ? (
            <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {error}
            </div>
          ) : null}

          <button
            type="submit"
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-white px-4 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-100"
          >
            <LogIn className="h-4 w-4" />
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}

function App() {
  const [pathname, setPathname] = useState(window.location.pathname);
  const [adminAuthed, setAdminAuthed] = useState(
    localStorage.getItem(AUTH_KEY) === 'true',
  );

  useEffect(() => {
    const onPopState = () => setPathname(window.location.pathname);
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const isAdminRoute = pathname.startsWith('/admin');

  useEffect(() => {
    if (!isAdminRoute) return;
    setAdminAuthed(localStorage.getItem(AUTH_KEY) === 'true');
  }, [isAdminRoute]);

  const handleLogout = () => {
    localStorage.removeItem(AUTH_KEY);
    setAdminAuthed(false);
  };

  if (isAdminRoute && !adminAuthed) {
    return <AdminLogin onLogin={setAdminAuthed} />;
  }

  if (isAdminRoute) {
    return <SafeReportAdminDashboard onLogout={handleLogout} />;
  }

  return <PublicReportForm />;
}

export default App;